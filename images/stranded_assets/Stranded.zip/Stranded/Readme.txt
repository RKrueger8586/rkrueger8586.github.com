To install:
Place warfaregame.int go to C:\Program Files\Microsoft Games\Gears of War\WarGame\Localization\INT\ 
And drop the file in. 

Note: You should probably make a copy of the original file before replacing it.Just a safety precaution.

Place the .war and .ini file in:
C:\Documents and Settings\guildhall\My Documents\My Games\Gears of War for Windows\WarGame\Published...
\CookedPC\Maps\CustomMaps Folder

To play:
1.)Make note of the file name (write it down, if necessary. You'll need it in a moment)
2.) Start Gears of War game
3.)At the main menu screen press the "~" key
4.)type "open FILENAME" (Do not incluse the .war extension)
5.)Enjoy!

Thank you for taking the time to play my level,


-Russell Krueger
 C11 Level Designer